import { Request, Response } from 'express'
import { ParamsDictionary } from 'express-serve-static-core'
import { TweetType } from '~/constants/enums'
import { PaginationQuery, TweetParams, TweetQuery, TweetReqBody } from '~/models/requests/tweet.requests'
import { TokenPayload } from '~/models/requests/user.requests'
import tweetService from '~/services/tweet.services'

export const createTweetController = async (req: Request<ParamsDictionary, any, TweetReqBody>, res: Response) => {
  const decoded_authorization = req.decoded_authorization as TokenPayload
  const result = await tweetService.createTweet(req.body, decoded_authorization?.user_id as string)
  return res.json({ message: 'Create tweet successfully', result })
}

export const getTweetController = async (req: Request, res: Response) => {
  const result = await tweetService.increateView(
    req.tweet?._id?.toString() as string,
    req.decoded_authorization?.user_id
  )

  const tweet = { ...req.tweet, ...result }
  return res.json({ message: 'Get tweet successfully', result: tweet })
}

export const getTweetChildrenController = async (req: Request<TweetParams, any, any, TweetQuery>, res: Response) => {
  const { tweet_id } = req.params
  const { limit, page, type } = req.query
  const user_id = req.decoded_authorization?.user_id
  const result = await tweetService.getTweetChildren({
    tweet_id,
    limit: Number(limit),
    page: Number(page),
    type: Number(type) as TweetType,
    user_id
  })
  return res.json({ message: 'Get Tweet Children Successfully', ...result })
}

export const getNewsFeedController = async (
  req: Request<ParamsDictionary, any, any, PaginationQuery>,
  res: Response
) => {
  const user_id = req.decoded_authorization?.user_id as string
  const { limit, page } = req.query
  const result = await tweetService.getNewsFeed({ user_id, limit: Number(limit), page: Number(page) })
  return res.json({ message: 'Get tweet successfully', result })
}
