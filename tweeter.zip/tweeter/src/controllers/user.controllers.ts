import { Request, Response } from 'express'
import { ParamsDictionary } from 'express-serve-static-core'
import { ObjectId } from 'mongodb'
import { UserVerifyStatus } from '~/constants/enums'
import HTTP_STATUS from '~/constants/httpStatus'
import { USER_MESSAGES } from '~/constants/messages'
import {
  ChangePasswordReqBody,
  FollowReqBody,
  ForgotPasswordReqBody,
  ForgotPasswordTokenReqBody,
  GetProfileReqParams,
  LoginReqBody,
  LogoutReqBody,
  RefreshTokenReqBody,
  RegisterReqBody,
  TokenPayload,
  UnfollowReqParams,
  UpdateMeReqBody,
  VerifyEmailReqBody
} from '~/models/requests/user.requests'
import User from '~/models/schemas/User.schema'
import databaseService from '~/services/database.services'
import userService from '~/services/users.services'

export const loginController = async (req: Request<ParamsDictionary, any, LoginReqBody>, res: Response) => {
  const user = req.user as User
  const user_id = user._id as ObjectId
  const verify: UserVerifyStatus = user.verify
  const result = await userService.login({ user_id: user_id.toString() as string, verify })
  return res.json({ message: USER_MESSAGES.LOGIN_SUCCESS, result })
}

export const refreshTokenController = async (
  req: Request<ParamsDictionary, any, RefreshTokenReqBody>,
  res: Response
) => {
  const { refresh_token } = req.body
  const { user_id, verify } = req.decoded_refresh_token as TokenPayload
  const result = await userService.refreshToken({ user_id, verify, old_token: refresh_token })
  return res.json({ message: USER_MESSAGES.REFRESH_TOKEN_SUCCESS, result })
}

export const registerController = async (req: Request<ParamsDictionary, any, RegisterReqBody>, res: Response) => {
  const result = await userService.register(req.body)
  return res.json({
    message: USER_MESSAGES.REGISTER_SUCCESS,
    result
  })
}

export const logoutController = async (req: Request<ParamsDictionary, any, LogoutReqBody>, res: Response) => {
  const { refresh_token } = req.body
  const result = await userService.logout(refresh_token)
  return res.json(result)
}

export const verifyEmailController = async (req: Request<ParamsDictionary, any, VerifyEmailReqBody>, res: Response) => {
  const { decoded_forgot_password_token } = req
  const user = await databaseService.users.findOne({ _id: new ObjectId(decoded_forgot_password_token?.user_id) })
  if (!user) {
    return res.status(HTTP_STATUS.NOT_FOUND).json({ message: USER_MESSAGES.USER_NOT_FOUND })
  }
  if (user.email_verify_token === '') {
    return res.json({ message: USER_MESSAGES.EMAIL_ALREADY_VERIFIED_BEFORE })
  }
  const result = await userService.verifyEmail(user._id.toString())
  return res.json({ message: USER_MESSAGES.EMAIL_VERIFY_SUCCESS, result })
}

export const resendVerifyEmailController = async (req: Request, res: Response) => {
  const { user_id } = req.decoded_authorization as TokenPayload
  const user = await databaseService.users.findOne({ _id: new ObjectId(user_id) })
  if (!user) {
    return res.status(HTTP_STATUS.NOT_FOUND).json({ message: USER_MESSAGES.USER_NOT_FOUND })
  }
  if (user.verify === UserVerifyStatus.Verified) {
    return res.json({ message: USER_MESSAGES.EMAIL_ALREADY_VERIFIED_BEFORE })
  }
  const result = await userService.resendVerifyEmail(user_id)
  return res.json(result)
}

export const forgotPasswordController = async (
  req: Request<ParamsDictionary, any, ForgotPasswordReqBody>,
  res: Response
) => {
  const user = req.user as User
  const user_id = user._id as ObjectId
  const verify = user.verify as UserVerifyStatus
  const result = await userService.forgotPassword({ user_id: user_id.toString(), verify: verify })
  return res.json({ result })
}

export const verifyForgotPasswordTokenController = async (
  req: Request<ParamsDictionary, any, VerifyEmailReqBody>,
  res: Response
) => {
  return res.json({ message: USER_MESSAGES.VERIFY_FORGOT_PASSWORD_SUCCESS })
}

export const resetPasswordController = async (
  req: Request<ParamsDictionary, any, ForgotPasswordTokenReqBody>,
  res: Response
) => {
  const decoded_forgot_password_token = req?.decoded_forgot_password_token
  const user_id = decoded_forgot_password_token?.user_id
  const verify = req.user?.verify
  const result = await userService.resetPassword(user_id as string, req.body.password, verify as UserVerifyStatus)
  return res.json(result)
}

export const getMeController = async (req: Request, res: Response) => {
  const { decoded_authorization } = req
  const user_id = decoded_authorization?.user_id
  const result = await userService.getMe(user_id as string)
  return res.json({ message: USER_MESSAGES.GET_ME_SUCCESS, result })
}

export const updateMeController = async (req: Request<ParamsDictionary, any, UpdateMeReqBody>, res: Response) => {
  const { user_id } = req.decoded_authorization as TokenPayload
  const user = await userService.updateMe(user_id, req.body)
  return res.json({ message: USER_MESSAGES.UPDATE_ME_SUCCESS, result: user })
}

export const getProfileController = async (req: Request<GetProfileReqParams>, res: Response) => {
  const { username } = req.params
  const user = await userService.getProfile(username)
  return res.json({ message: USER_MESSAGES.GET_PROFILE_SUCCESS, result: user })
}

export const followController = async (req: Request<ParamsDictionary, any, FollowReqBody>, res: Response) => {
  const user_id = req.decoded_authorization?.user_id
  const { followed_user_id } = req.body
  const result = await userService.follow(user_id as string, followed_user_id as string)
  return res.json(result)
}

export const unfollowController = async (req: Request<UnfollowReqParams>, res: Response) => {
  const user_id = req.decoded_authorization?.user_id
  const followed_user_id = req.params.followed_user_id

  const record = await userService.unfollow(user_id as string, followed_user_id)
  return res.json(record)
}

export const changePasswordController = async (
  req: Request<ParamsDictionary, any, ChangePasswordReqBody>,
  res: Response
) => {
  const { password } = req.body
  const user_id = req.decoded_authorization?.user_id as string
  const result = await userService.changePassword(user_id, password)
  return res.json({ message: USER_MESSAGES.CHANGE_PASSWORD_SUCCESS })
}
