import { Request, Response } from 'express'
import path from 'path'
import { UPLOAD_IMAGE_DIR, UPLOAD_VIDEO_DIR } from '~/constants/dir'
import HTTP_STATUS from '~/constants/httpStatus'
import { USER_MESSAGES } from '~/constants/messages'
import mediaService from '~/services/media.services'
import fs from 'fs'
import mime from 'mime'

export const uploadImagesController = async (req: Request, res: Response) => {
  const info = await mediaService.handleUploadImages(req)
  return res.json({ message: USER_MESSAGES.UPLOAD_SUCCESS, result: info })
}

export const serveImageController = async (req: Request, res: Response) => {
  const { name } = req.params
  return res.sendFile(path.resolve(UPLOAD_IMAGE_DIR, name))
}

export const serveVideoStreamController = async (req: Request, res: Response) => {
  const range = req.headers.range
  if (!range) {
    return res.status(HTTP_STATUS.BAD_REQUEST).send('Requires Range header')
  }
  const { name } = req.params
  const videoPath = path.resolve(UPLOAD_VIDEO_DIR, name)

  const videoSize = fs.statSync(videoPath).size
  const chunkSize = 10 ** 6 // 30MB
  const start = Number(range.replace(/\D/g, ''))
  const end = Math.min(start + chunkSize, videoSize - 1)

  const contentLength = end - start + 1
  const contentType = mime.getType(videoPath) || 'video/*'

  const headers = {
    'Content-Range': `bytes ${start}-${end}/${videoSize}`,
    'Accept-Ranges': 'bytes',
    'Content-Length': contentLength,
    'Content-Type': contentType
  }
  console.log(headers)
  res.writeHead(HTTP_STATUS.PARTIAL_CONTENT, headers)
  const videoSteams = fs.createReadStream(videoPath, { start, end })
  videoSteams.pipe(res)
}

export const uploadVideosController = async (req: Request, res: Response) => {
  const info = await mediaService.handleUploadVideo(req)
  return res.json({ mesage: USER_MESSAGES.UPLOAD_SUCCESS, result: info })
}

export const uploadVideoHLSController = async (req: Request, res: Response) => {
  const info = await mediaService.handleUploadVideoHLS(req)
  return res.json({ message: USER_MESSAGES.UPLOAD_SUCCESS, result: info })
}
