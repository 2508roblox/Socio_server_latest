import { SearchQuery } from '~/models/requests/search.requests'
import { Request, Response, NextFunction } from 'express'
import { ParamsDictionary } from 'express-serve-static-core'
import searchService from '~/services/search.services'

export const searchController = async (req: Request<ParamsDictionary, any, any, SearchQuery>, res: Response) => {
  const limit = Number(req.query.limit)
  const page = Number(req.query.page)
  const mediaType = req.query.media_type
  const userId = req.decoded_authorization?.user_id as string

  const result = await searchService.search({ limit, page, content: req.query.content, userId, mediaType })

  return res.json({ message: 'Search Successfully', result })
}
