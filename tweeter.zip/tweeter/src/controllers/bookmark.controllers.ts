import { Request, Response } from 'express'
import { ParamsDictionary } from 'express-serve-static-core'
import { BookmarkReqBody, BookmarkReqParams } from '~/models/requests/bookmark.requests'
import { TokenPayload } from '~/models/requests/user.requests'
import bookmarkService from '~/services/bookmark.services'

export const bookmarkTweetController = async (req: Request<ParamsDictionary, any, BookmarkReqBody>, res: Response) => {
  const user_id = (req.decoded_authorization as TokenPayload).user_id
  const result = await bookmarkService.bookmarkTweet(req.body, user_id)
  return res.json({ message: 'Bookmark successfully', result })
}

export const unbookmarkTweetController = async (req: Request<BookmarkReqParams>, res: Response) => {
  const { tweet_id } = req.params
  const { user_id } = req.decoded_authorization as TokenPayload
  const result = await bookmarkService.unbookmarkTweet(tweet_id, user_id)
  return res.json({ message: 'Unbookmark successfully', result })
}
