import { SESClient, SendEmailCommand } from '@aws-sdk/client-ses'
import { envConfig } from '~/constants/config'

const sesClient = new SESClient({
  region: envConfig.awsRegion,
  credentials: {
    secretAccessKey: envConfig.awsSecretAccessKey,
    accessKeyId: envConfig.awsAccessKeyId
  }
})

const createSendEmailCommand = ({
  fromAddresses,
  toAddresses,
  ccAddresses = [],
  body,
  subject,
  replyToAddresses = []
}: {
  fromAddresses: string
  toAddresses: string[] | string
  ccAddresses?: string[] | string
  body: any
  subject: string
  replyToAddresses?: string[] | string
}) =>
  new SendEmailCommand({
    Destination: {
      CcAddresses: ccAddresses instanceof Array ? ccAddresses : [ccAddresses],
      ToAddresses: toAddresses instanceof Array ? toAddresses : [toAddresses]
    },
    Message: {
      Body: {
        Html: {
          Charset: 'utf-8',
          Data: body
        }
      },
      Subject: {
        Charset: 'utf-8',
        Data: subject
      }
    },
    Source: fromAddresses,
    ReplyToAddresses: replyToAddresses instanceof Array ? replyToAddresses : [replyToAddresses]
  })

const sendVerifyEmail = async ({
  toAddress,
  subject,
  body
}: {
  toAddress: string | string[]
  subject: string
  body: any
}) => {
  const sendEmailCommand = createSendEmailCommand({
    fromAddresses: envConfig.sesFromAddress,
    toAddresses: toAddress,
    body: body,
    subject: subject
  })

  try {
    return await sesClient.send(sendEmailCommand)
  } catch (e) {
    console.log('error')
    console.log(e)
  }
}

sendVerifyEmail({ toAddress: 'luongtruong20201@gmail.com', subject: 'lqt', body: '<h1>hello</h1>' })
