import formidable, { File } from 'formidable'
import { UPLOAD_IMAGE_TEMP_DIR, UPLOAD_VIDEO_DIR, UPLOAD_VIDEO_TEMP_DIR } from '~/constants/dir'
import { Request } from 'express'
import fs from 'fs'
import { v4 as uuidv4 } from 'uuid'
import path from 'path'

export const initFolder = async () => {
  ;[UPLOAD_IMAGE_TEMP_DIR, UPLOAD_VIDEO_TEMP_DIR].forEach((dir) => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true })
    }
  })
}

export const handleUploadImage = (req: Request) => {
  const form = formidable({
    keepExtensions: true,
    uploadDir: UPLOAD_IMAGE_TEMP_DIR,
    maxFiles: 50000,
    maxFileSize: 1024 * 1024 * 1024,
    maxTotalFileSize: 5000 * 1024 * 1024 * 1024,
    filename: function (name, ext, part, form) {
      const newName = uuidv4()
      return `${newName}${ext}`
    },
    filter: function ({ name, originalFilename, mimetype }) {
      const valid = name === 'image' && Boolean(mimetype?.includes('image/'))
      if (!valid) {
        form.emit('error' as any, new Error('File type is not valid') as any)
      }
      return valid
    }
  })

  return new Promise<File[]>((resolve, reject) => {
    form.parse(req, (err, fields, files) => {
      if (err) {
        return reject(err)
      }
      if (files.images?.length === 0) {
        return reject(new Error('File is empty'))
      }
      resolve(files.image as File[])
    })
  })
}

export const handleUploadVideo = (req: Request) => {
  const form = formidable({
    uploadDir: UPLOAD_VIDEO_TEMP_DIR,
    maxFileSize: 1024 ** 3,
    maxFiles: 1,
    keepExtensions: true,
    filename: (name, ext, part, form) => {
      const newName = uuidv4()
      return `${newName}${ext}`
    },
    filter: ({ name, originalFilename, mimetype }) => {
      const valid = name === 'video' && Boolean(mimetype?.includes('video/'))
      if (!valid) {
        form.emit('error' as any, new Error('File type is not valid') as any)
      }
      return valid
    }
  })

  return new Promise<File>((resolve, reject) => {
    form.parse(req, (err, fields, files) => {
      if (err) {
        return reject(err)
      }
      if (files.image?.length === 0) {
        return reject(new Error('File is empty'))
      }
      resolve((files.video as File[])[0])
    })
  })
}

export const handleUploadVideoHLS = (req: Request) => {
  const newName = uuidv4()
  const newPath = path.resolve(UPLOAD_VIDEO_DIR, newName)
  fs.mkdirSync(newPath)
  const form = formidable({
    uploadDir: newPath,
    maxFileSize: 1024 ** 3,
    maxFiles: 1,
    keepExtensions: true,
    filename: (name, ext, part, form) => {
      return `${newName}${ext}`
    },
    filter: ({ name, originalFilename, mimetype }) => {
      const valid = name === 'video' && Boolean(mimetype?.includes('video/'))
      if (!valid) {
        form.emit('error' as any, new Error('File type is not valid') as any)
      }
      return valid
    }
  })

  return new Promise<File>((resolve, reject) => {
    form.parse(req, (err, fields, files) => {
      if (err) {
        return reject(err)
      }
      if (files.image?.length === 0) {
        return reject(new Error('File is empty'))
      }
      resolve((files.video as File[])[0])
    })
  })
}

export const getName = (videoPath: string) => {
  return (videoPath.split('/').pop() as string).replace('.mp4', '')
}
