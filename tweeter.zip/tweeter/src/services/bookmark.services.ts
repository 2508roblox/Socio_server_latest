import { BookmarkReqBody } from '~/models/requests/bookmark.requests'
import databaseService from './database.services'
import Bookmark from '~/models/schemas/Bookmark.schema'
import { ObjectId } from 'mongodb'

class BookmarkService {
  async bookmarkTweet(payload: BookmarkReqBody, user_id: string) {
    const result = await databaseService.bookmarks.findOneAndUpdate(
      {
        user_id: new ObjectId(user_id),
        tweet_id: new ObjectId(payload.tweet_id)
      },
      { $setOnInsert: new Bookmark({ user_id: new ObjectId(user_id), tweet_id: new ObjectId(payload.tweet_id) }) },
      { upsert: true, returnDocument: 'after' }
    )
    return result
  }

  async unbookmarkTweet(tweet_id: string, user_id: string) {
    const result = await databaseService.bookmarks.deleteOne({
      user_id: new ObjectId(user_id),
      tweet_id: new ObjectId(tweet_id)
    })
    return result
  }
}

const bookmarkService = new BookmarkService()
export default bookmarkService
