import { ObjectId } from 'mongodb'
import databaseService from './database.services'
import { MediaType, MediaTypeQuery, TweetType } from '~/constants/enums'

class SearchService {
  async search({
    limit,
    page,
    content,
    userId,
    mediaType
  }: {
    limit: number
    page: number
    content: string
    userId: string
    mediaType: MediaTypeQuery
  }) {
    const $match: any = {
      $text: {
        $search: content
      }
    }

    if (mediaType === MediaTypeQuery.Image) {
      $match['medias.type'] = MediaType.Image
    }
    if (mediaType === MediaTypeQuery.Video) {
      $match['medias.type'] = {
        $in: [MediaType.Video, MediaType.HLS]
      }
    }

    console.log('check $match: ', $match)

    const [result, [{ total }]] = await Promise.all([
      databaseService.tweets
        .aggregate([
          {
            $match
          },
          {
            $lookup: {
              from: 'users',
              localField: 'user_id',
              foreignField: '_id',
              as: 'user'
            }
          },
          {
            $unwind: {
              path: '$user'
            }
          },
          {
            $match: {
              $or: [
                {
                  audience: 0
                },
                {
                  $and: [
                    {
                      audience: 1
                    },
                    {
                      'user.tweet_circle': {
                        $in: [new ObjectId(userId)]
                      }
                    }
                  ]
                }
              ]
            }
          },
          {
            $lookup: {
              from: 'hashtags',
              localField: 'hashtags',
              foreignField: '_id',
              as: 'hashtags'
            }
          },
          {
            $lookup: {
              from: 'users',
              localField: 'mentions',
              foreignField: '_id',
              as: 'mentions'
            }
          },
          {
            $addFields: {
              mentions: {
                $map: {
                  input: '$mentions',
                  as: 'mention',
                  in: {
                    _id: '$$mention._id',
                    name: '$$mention.name',
                    username: '$$mention.username',
                    email: '$$mention.email'
                  }
                }
              }
            }
          },
          {
            $lookup: {
              from: 'bookmarks',
              localField: 'bookmarks',
              foreignField: '_id',
              as: 'bookmarks'
            }
          },
          {
            $lookup: {
              from: 'likes',
              localField: '_id',
              foreignField: 'tweet_id',
              as: 'likes'
            }
          },
          {
            $lookup: {
              from: 'tweets',
              localField: '_id',
              foreignField: 'parent_id',
              as: 'tweet_childrens'
            }
          },
          {
            $addFields: {
              bookmarks: {
                $size: '$bookmarks'
              },
              likes: {
                $size: '$likes'
              },
              retweet_count: {
                $size: {
                  $filter: {
                    input: '$tweet_childrens',
                    as: 'child',
                    cond: {
                      $eq: ['$$child.type', TweetType.Retweet]
                    }
                  }
                }
              },
              comment_count: {
                $size: {
                  $filter: {
                    input: '$tweet_childrens',
                    as: 'child',
                    cond: {
                      $eq: ['$$child.type', TweetType.Comment]
                    }
                  }
                }
              },
              qoute_count: {
                $size: {
                  $filter: {
                    input: '$tweet_childrens',
                    as: 'child',
                    cond: {
                      $eq: ['$$child.type', TweetType.QouteTweet]
                    }
                  }
                }
              }
            }
          },
          {
            $project: {
              tweet_childrens: 0,
              user: {
                password: 0,
                email_verify_token: 0,
                forgot_password_token: 0,
                tweet_circle: 0,
                date_of_birth: 0,
                created_at: 0,
                updated_at: 0,
                verify: 0
              }
            }
          },
          {
            $skip: limit * (page - 1)
          },
          {
            $limit: limit
          }
        ])
        .toArray(),
      databaseService.tweets
        .aggregate([
          {
            $match
          },
          {
            $lookup: {
              from: 'users',
              localField: 'user_id',
              foreignField: '_id',
              as: 'user'
            }
          },
          {
            $unwind: {
              path: '$user'
            }
          },
          {
            $match: {
              $or: [
                {
                  audience: 0
                },
                {
                  $and: [
                    {
                      audience: 1
                    },
                    {
                      'user.twitter_circle': {
                        $in: [new ObjectId(userId)]
                      }
                    }
                  ]
                }
              ]
            }
          },
          {
            $count: 'total'
          }
        ])
        .toArray()
    ])

    return { result, page, limit, total }
  }
}

const searchService = new SearchService()

export default searchService
