import { Request } from 'express'
import path from 'path'
import sharp from 'sharp'
import fs from 'fs'
import { unlink } from 'fs/promises'
import { UPLOAD_IMAGE_DIR } from '~/constants/dir'
import { getName, handleUploadImage, handleUploadVideo, handleUploadVideoHLS } from '~/utils/file'
import { Media } from '~/models/Other'
import { EncodingStatus, MediaType } from '~/constants/enums'
import { encodeHLSWithMultipleVideoStreams } from '~/utils/video'
import databaseService from './database.services'
import VideoStatus from '~/models/schemas/VideoStatus.schema'
import { envConfig } from '~/constants/config'

class Queue {
  items: string[]
  encoding: boolean

  constructor() {
    this.items = []
    this.encoding = false
  }

  async enqueue(item: string) {
    this.items.push(item)
    const name = getName(item)
    await databaseService.videoStatus.insertOne(new VideoStatus({ name, status: EncodingStatus.Pending }))
    this.processEncode()
  }

  async processEncode() {
    if (this.encoding) return
    if (this.items.length > 0) {
      this.encoding = true
      const videoPath = this.items[0]
      const name = getName(videoPath)
      await databaseService.videoStatus.updateOne(
        { name: name },
        {
          $set: {
            status: EncodingStatus.Processing
          },
          $currentDate: { updated_at: true }
        }
      )
      try {
        await encodeHLSWithMultipleVideoStreams(videoPath)
        this.items.shift()
        await unlink(videoPath)
        console.log(`Encode video ${videoPath} success`)
        await databaseService.videoStatus.updateOne(
          { name: name },
          {
            $set: {
              status: EncodingStatus.Success
            },
            $currentDate: { updated_at: true }
          }
        )
      } catch (error) {
        console.error(`Encode video ${videoPath} error`)
        await databaseService.videoStatus.updateOne(
          { name: name },
          {
            $set: {
              status: EncodingStatus.Failed
            },
            $currentDate: { updated_at: true }
          }
        )
        console.error(error)
      }
      this.encoding = false
      this.processEncode()
    } else {
      console.log('Encode video queue is empty')
    }
  }
}

const queue = new Queue()

class MediaService {
  async handleUploadImages(req: Request) {
    const files = await handleUploadImage(req)
    const result: Media[] = await Promise.all(
      files.map(async (file) => {
        const newPath = path.resolve(UPLOAD_IMAGE_DIR, file.newFilename as string)
        await sharp(file.filepath).jpeg().toFile(newPath)
        fs.unlinkSync(file.filepath)
        return {
          url: `http://localhost:4000/static/image/${file.newFilename}`,
          type: MediaType.Image
        }
      })
    )
    return result
  }

  async handleUploadVideo(req: Request) {
    const file = await handleUploadVideo(req)
    const result: Media = {
      url: `http://localhost:${envConfig.port}/static/video-stream/${file.newFilename}`,
      type: MediaType.Video
    }
    return result
  }

  async handleUploadVideoHLS(req: Request) {
    const file = await handleUploadVideoHLS(req)
    queue.enqueue(file.filepath)
    file.newFilename = file.newFilename.replace('mp4', 'm3u8')
    const result: Media = {
      url: `http://localhost:${envConfig.port}/static/video-hls/${file.newFilename}`,
      type: MediaType.HLS
    }
    return result
  }
}

const mediaService = new MediaService()

export default mediaService
