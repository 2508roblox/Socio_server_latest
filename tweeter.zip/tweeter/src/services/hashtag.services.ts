class HashtagService {}

const hashtagService = new HashtagService()
export default hashtagService
