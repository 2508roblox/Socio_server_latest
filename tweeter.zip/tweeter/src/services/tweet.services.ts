import { TweetReqBody } from '~/models/requests/tweet.requests'
import databaseService from './database.services'
import Tweet from '~/models/schemas/Tweet.schema'
import { ObjectId, WithId } from 'mongodb'
import Hashtag from '~/models/schemas/Hashtag.schema'
import { TweetType } from '~/constants/enums'

class TweetService {
  async checkAndCreateHashtag(hashtags: string[]) {
    const hashtagDocuments = await Promise.all(
      hashtags.map(async (hashtag) => {
        return databaseService.hashtags.findOneAndUpdate(
          { name: hashtag },
          { $setOnInsert: new Hashtag({ name: hashtag, _id: new ObjectId() }) },
          { upsert: true, returnDocument: 'after' }
        )
      })
    )
    return hashtagDocuments.map((item) => item?._id)
  }

  async createTweet(body: TweetReqBody, user_id: string) {
    const hashtags = (await this.checkAndCreateHashtag(body.hashtags)) as ObjectId[]
    const result = await databaseService.tweets.insertOne(
      new Tweet({
        audience: body.audience,
        content: body.content,
        hashtags,
        mentions: body.mentions,
        medias: body.medias,
        parent_id: body.parent_id,
        type: body.type,
        user_id: new ObjectId(user_id)
      })
    )
    const tweet = await databaseService.tweets.findOne({ _id: result.insertedId })
    return tweet
  }

  async increateView(tweet_id: string, user_id?: string) {
    const inc = user_id ? { user_views: 1 } : { guest_views: 1 }
    const result = await databaseService.tweets.findOneAndUpdate(
      { _id: new ObjectId(tweet_id) },
      { $inc: inc, $currentDate: { updated_at: true } },
      { returnDocument: 'after', projection: { guest_views: 1, user_views: 1, updated_at: 1 } }
    )
    return result
  }

  async getTweetChildren({
    tweet_id,
    limit,
    page,
    type,
    user_id
  }: {
    tweet_id: string
    limit: number
    page: number
    type: TweetType
    user_id?: string
  }) {
    const tweets = await databaseService.tweets
      .aggregate<Tweet>([
        {
          $match: {
            parent_id: new ObjectId(tweet_id),
            type: type
          }
        },
        {
          $skip: (page - 1) * limit
        },
        {
          $limit: limit
        },
        {
          $lookup: {
            from: 'hashtags',
            localField: 'hashtags',
            foreignField: '_id',
            as: 'hashtags'
          }
        },
        {
          $lookup: {
            from: 'users',
            localField: 'mentions',
            foreignField: '_id',
            as: 'mentions'
          }
        },
        {
          $lookup: {
            from: 'bookmarks',
            localField: 'bookmarks',
            foreignField: '_id',
            as: 'bookmarks'
          }
        },
        {
          $lookup: {
            from: 'likes',
            localField: '_id',
            foreignField: 'tweet_id',
            as: 'likes'
          }
        },
        {
          $addFields: {
            mentions: {
              $map: {
                input: '$mentions',
                as: 'item',
                in: {
                  _id: '$$item._id',
                  name: '$$item.name',
                  username: '$$item.username',
                  email: '$$item.email'
                }
              }
            }
          }
        },
        {
          $lookup: {
            from: 'tweets',
            localField: '_id',
            foreignField: 'parent_id',
            as: 'tweet-childrens'
          }
        },
        {
          $addFields: {
            bookmarks: {
              $size: '$bookmarks'
            },
            likes: {
              $size: '$likes'
            },
            retweet_count: {
              $size: {
                $filter: {
                  input: '$tweet-childrens',
                  as: 'childs',
                  cond: {
                    $eq: ['$$childs.type', TweetType.Retweet]
                  }
                }
              }
            },
            qoute_count: {
              $size: {
                $filter: {
                  input: '$tweet-childrens',
                  as: 'childs',
                  cond: {
                    $eq: ['$$childs.type', TweetType.QouteTweet]
                  }
                }
              }
            },
            comment_count: {
              $size: {
                $filter: {
                  input: '$tweet-childrens',
                  as: 'childs',
                  cond: {
                    $eq: ['$$childs.type', TweetType.Comment]
                  }
                }
              }
            }
          }
        },
        {
          $project: {
            'tweet-childrens': 0
          }
        }
      ])
      .toArray()

    const ids = tweets.map((tweet) => tweet._id as ObjectId)
    const inc = user_id ? { user_views: 1 } : { guest_views: 1 }
    const date = new Date()

    const [, total] = await Promise.all([
      databaseService.tweets.updateMany({ _id: { $in: ids } }, { $inc: inc, $set: { updated_at: date } }),
      databaseService.tweets.countDocuments({ parent_id: new ObjectId(tweet_id), type })
    ])
    tweets.forEach((tweet) => {
      tweet.updated_at = date
      if (user_id) {
        tweet.user_views += 1
      } else {
        tweet.guest_views += 1
      }
    })
    const pages = Math.ceil(total / limit)

    return { tweets, totalPage: pages, page, limit }
  }

  async getNewsFeed({ user_id, page, limit }: { user_id: string; page: number; limit: number }) {
    const followed_user_ids = await databaseService.followers
      .find({ user_id: new ObjectId(user_id) }, { projection: { followed_user_id: 1, _id: 0 } })
      .toArray()
    const ids = followed_user_ids.map((item) => item.followed_user_id)

    const tweets = databaseService.tweets
      .aggregate<Tweet>([
        {
          $match: {
            user_id: {
              $in: [new ObjectId(user_id), ...ids]
            }
          }
        },
        {
          $lookup: {
            from: 'users',
            localField: 'user_id',
            foreignField: '_id',
            as: 'user'
          }
        },
        {
          $unwind: {
            path: '$user'
          }
        },
        {
          $match: {
            $or: [
              {
                audience: 0
              },
              {
                $and: [
                  {
                    audience: 1
                  },
                  {
                    'user.tweet_circle': {
                      $in: [new ObjectId(user_id)]
                    }
                  }
                ]
              }
            ]
          }
        },
        {
          $skip: (page - 1) * limit
        },
        {
          $limit: limit
        },
        {
          $lookup: {
            from: 'hashtags',
            localField: 'hashtags',
            foreignField: '_id',
            as: 'hashtags'
          }
        },
        {
          $lookup: {
            from: 'users',
            localField: 'mentions',
            foreignField: '_id',
            as: 'mentions'
          }
        },
        {
          $addFields: {
            mentions: {
              $map: {
                input: '$mentions',
                as: 'mention',
                in: {
                  _id: '$$mention._id',
                  name: '$$mention.name',
                  username: '$$mention.username',
                  email: '$$mention.email'
                }
              }
            }
          }
        },
        {
          $lookup: {
            from: 'bookmarks',
            localField: 'bookmarks',
            foreignField: '_id',
            as: 'bookmarks'
          }
        },
        {
          $lookup: {
            from: 'likes',
            localField: '_id',
            foreignField: 'tweet_id',
            as: 'likes'
          }
        },
        {
          $lookup: {
            from: 'tweets',
            localField: '_id',
            foreignField: 'parent_id',
            as: 'tweet_childrens'
          }
        },
        {
          $addFields: {
            bookmarks: {
              $size: '$bookmarks'
            },
            likes: {
              $size: '$likes'
            },
            retweet_count: {
              $size: {
                $filter: {
                  input: '$tweet_childrens',
                  as: 'child',
                  cond: {
                    $eq: ['$$child.type', TweetType.Retweet]
                  }
                }
              }
            },
            comment_count: {
              $size: {
                $filter: {
                  input: '$tweet_childrens',
                  as: 'child',
                  cond: {
                    $eq: ['$$child.type', TweetType.Comment]
                  }
                }
              }
            },
            qoute_count: {
              $size: {
                $filter: {
                  input: '$tweet_childrens',
                  as: 'child',
                  cond: {
                    $eq: ['$$child.type', TweetType.QouteTweet]
                  }
                }
              }
            }
          }
        },
        {
          $project: {
            tweet_childrens: 0,
            user: {
              password: 0,
              email_verify_token: 0,
              forgot_password_token: 0,
              tweet_circle: 0,
              date_of_birth: 0,
              created_at: 0,
              updated_at: 0,
              verify: 0
            }
          }
        }
      ])
      .toArray()

    return tweets
  }
}

const tweetService = new TweetService()
export default tweetService
