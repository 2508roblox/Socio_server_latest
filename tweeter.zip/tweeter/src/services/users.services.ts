import User from '~/models/schemas/User.schema'
import databaseService from './database.services'
import { RegisterReqBody, UpdateMeReqBody } from '~/models/requests/user.requests'
import { hashPassword } from '~/utils/crypto'
import { signToken } from '~/utils/jwt'
import { TokenType, UserVerifyStatus } from '~/constants/enums'
import { config } from 'dotenv'
import RefreshToken from '~/models/schemas/RefresToken.schema'
import { ObjectId } from 'mongodb'
import { USER_MESSAGES } from '~/constants/messages'
import { ErrorWithStatus } from '~/models/Errors'
import HTTP_STATUS from '~/constants/httpStatus'
import { Follower } from '~/models/schemas/Follower.schema'
import { envConfig } from '~/constants/config'

config()

class UserService {
  async login({ user_id, verify }: { user_id: string; verify: UserVerifyStatus }) {
    const { access_token, refresh_token } = await this.signAccessAndRefreshToken({ user_id, verify })
    await databaseService.refreshTokens.insertOne(
      new RefreshToken({ token: refresh_token, user_id: new ObjectId(user_id) })
    )
    return { access_token, refresh_token }
  }

  async refreshToken({ user_id, verify, old_token }: { user_id: string; verify: UserVerifyStatus; old_token: string }) {
    const [{ access_token, refresh_token }] = await Promise.all([
      this.signAccessAndRefreshToken({ user_id, verify }),
      databaseService.refreshTokens.deleteOne({ token: old_token })
    ])
    await databaseService.refreshTokens.insertOne(
      new RefreshToken({ token: refresh_token, user_id: new ObjectId(user_id) })
    )
    return { refresh_token, access_token }
  }

  async register(payload: RegisterReqBody) {
    const user_id: ObjectId = new ObjectId()
    const email_verify_token = await this.signEmailVerifyToken({
      user_id: user_id.toString(),
      verify: UserVerifyStatus.Unverified
    })
    await databaseService.users.insertOne(
      new User({
        ...payload,
        date_of_birth: new Date(payload.date_of_birth),
        password: hashPassword(payload.password),
        _id: user_id,
        email_verify_token,
        username: `user${user_id.toString()}`
      })
    )
    const { access_token, refresh_token } = await this.signAccessAndRefreshToken({
      user_id: user_id.toString(),
      verify: UserVerifyStatus.Unverified
    })
    await databaseService.refreshTokens.insertOne(new RefreshToken({ token: refresh_token, user_id }))
    console.log('send email: ', email_verify_token)
    return { access_token, refresh_token }
  }

  async logout(refresh_token: string) {
    await databaseService.refreshTokens.deleteOne({ token: refresh_token })
    return { message: USER_MESSAGES.LOGOUT_SUCCESS }
  }

  async verifyEmail(user_id: string) {
    const [, { access_token, refresh_token }] = await Promise.all([
      await databaseService.users.updateOne(
        { _id: new ObjectId(user_id) },
        { $set: { updated_at: new Date(), email_verify_token: '', verify: UserVerifyStatus.Verified } }
      ),
      this.signAccessAndRefreshToken({ user_id: user_id, verify: UserVerifyStatus.Unverified })
    ])
    await databaseService.refreshTokens.insertOne(
      new RefreshToken({ user_id: new ObjectId(user_id), token: refresh_token })
    )
    return { refresh_token, access_token }
  }

  async checkEmailExist(email: string) {
    const user = await databaseService.users.findOne({ email })
    return Boolean(user)
  }

  async resendVerifyEmail(user_id: string) {
    const email_verify_token = await this.signEmailVerifyToken({ user_id, verify: UserVerifyStatus.Unverified })
    console.log('Resend verify email: ', email_verify_token)

    await databaseService.users.updateOne(
      { _id: new ObjectId(user_id) },
      { $set: { email_verify_token }, $currentDate: { updated_at: true } }
    )
    return { message: USER_MESSAGES.RESEND_VERIFY_EMAIL_SUCCESS }
  }

  async forgotPassword({ user_id, verify }: { user_id: string; verify: UserVerifyStatus }) {
    const forgot_password_token = await this.signForgotPasswordToken({ user_id, verify })
    await databaseService.users.updateOne(
      { _id: new ObjectId(user_id) },
      {
        $set: { forgot_password_token },
        $currentDate: { updated_at: true }
      }
    )
    console.log('send forgot_password_token: ', forgot_password_token)
    return { message: USER_MESSAGES.CHECK_EMAIL_TO_RESET_PASSWORD }
  }

  async resetPassword(user_id: string, password: string, verify: UserVerifyStatus) {
    const [, ,] = await Promise.all([
      databaseService.users.updateOne(
        { _id: new ObjectId(user_id) },
        { $set: { password: hashPassword(password), forgot_password_token: '' }, $currentDate: { updated_at: true } }
      ),
      this.signAccessAndRefreshToken({ user_id: user_id, verify: verify })
    ])
    return { message: USER_MESSAGES.RESET_PASSWORD_SUCCESS }
  }

  async getMe(user_id: string) {
    const result = await databaseService.users.findOne(
      { _id: new ObjectId(user_id) },
      { projection: { password: 0, email_verify_token: 0, forgot_password_token: 0 } }
    )
    return result
  }

  async updateMe(user_id: string, payload: UpdateMeReqBody) {
    const _payload = payload.date_of_birth ? { ...payload, date_of_birth: new Date(payload.date_of_birth) } : payload
    const user = await databaseService.users.findOneAndUpdate(
      { _id: new ObjectId(user_id) },
      { $set: { ...(_payload as UpdateMeReqBody & { date_of_birth?: Date }) }, $currentDate: { updated_at: true } },
      {
        returnDocument: 'after',
        projection: { password: 0, email_verify_token: 0, forgot_password_token: 0, verify: 0 }
      }
    )
    return user
  }

  async getProfile(username: string) {
    const user = await databaseService.users.findOne(
      { username },
      {
        projection: {
          forgot_password_token: 0,
          verify: 0,
          password: 0,
          email_verify_token: 0,
          created_at: 0,
          updated_at: 0
        }
      }
    )
    if (user === null) {
      throw new ErrorWithStatus({ message: USER_MESSAGES.USER_NOT_FOUND, status: HTTP_STATUS.NOT_FOUND })
    }
    return user
  }

  async follow(user_id: string, followed_user_id: string) {
    const follower = await databaseService.followers.findOne({
      user_id: new ObjectId(user_id),
      followed_user_id: new ObjectId(followed_user_id)
    })
    if (follower === null) {
      await databaseService.followers.insertOne(
        new Follower({ user_id: new ObjectId(user_id), followed_user_id: new ObjectId(followed_user_id) })
      )
      return { message: USER_MESSAGES.FOLLOW_SUCCESS }
    }
    return { message: USER_MESSAGES.FOLLOWED }
  }

  async unfollow(user_id: string, followed_user_id: string) {
    const record = await databaseService.followers.deleteOne({
      user_id: new ObjectId(user_id),
      followed_user_id: new ObjectId(followed_user_id)
    })
    if (record.deletedCount === 0) {
      return { message: USER_MESSAGES.ALREADY_UNFOLLOWED }
    }
    return { message: USER_MESSAGES.UNFOLLOW_SUCCESS }
  }

  async changePassword(user_id: string, password: string) {
    await databaseService.users.updateOne(
      { _id: new ObjectId(user_id) },
      {
        $set: {
          password: hashPassword(password)
        },
        $currentDate: { updated_at: true }
      }
    )
    return { message: USER_MESSAGES.CHANGE_PASSWORD_SUCCESS }
  }

  private signAccessToken = ({ user_id, verify }: { user_id: string; verify: UserVerifyStatus }) => {
    return signToken({
      payload: { user_id, type: TokenType.AccessToken, verify },
      privateKey: envConfig.jwtSecretAccessToken,
      options: { expiresIn: envConfig.accessTokenExpiresIn }
    })
  }

  private signRefreshToken = ({ user_id, verify }: { user_id: string; verify: UserVerifyStatus }) => {
    return signToken({
      payload: { user_id, type: TokenType.RefreshToken, verify },
      options: { expiresIn: envConfig.refreshTokenExpiresIn },
      privateKey: envConfig.jwtSecretRefreshToken
    })
  }

  private signEmailVerifyToken = ({ user_id, verify }: { user_id: string; verify: UserVerifyStatus }) => {
    return signToken({
      payload: { user_id, type: TokenType.EmailVerifyToken, verify },
      options: { expiresIn: envConfig.emailVerifyTokenExpiresIn },
      privateKey: envConfig.jwtSecretEmailVerifyToken
    })
  }

  private signForgotPasswordToken = ({ user_id, verify }: { user_id: string; verify: UserVerifyStatus }) => {
    return signToken({
      payload: { user_id, type: TokenType.ForgotPasswordToken, verify },
      options: { expiresIn: envConfig.forgotPasswordTokenExpiresIn },
      privateKey: envConfig.jwtSecretForgotPasswordToken
    })
  }

  private signAccessAndRefreshToken = async ({ user_id, verify }: { user_id: string; verify: UserVerifyStatus }) => {
    const [access_token, refresh_token] = await Promise.all([
      this.signAccessToken({ user_id, verify }),
      this.signRefreshToken({ user_id, verify })
    ])

    return { access_token, refresh_token }
  }
}

const userService = new UserService()

export default userService
