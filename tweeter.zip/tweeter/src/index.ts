import express from 'express'
import { defaultErrorHandler } from './middlewares/error.middlewares'
import userRouter from './routes/user.routes'
import databaseService from './services/database.services'
import mediaRoutes from './routes/media.routes'
import { initFolder } from './utils/file'
import staticRoutes from './routes/static.routes'
import { UPLOAD_VIDEO_DIR } from './constants/dir'
import tweetRoutes from './routes/tweet.routes'
import bookmarkRoutes from './routes/bookmark.routes'
import likeRoutes from './routes/like.routes'
import searchRoutes from './routes/search.routes'
import helmet from 'helmet'
import cors, { CorsOptions } from 'cors'
import { rateLimit } from 'express-rate-limit'
import { envConfig } from './constants/config'
// import '~/utils/fake'

databaseService.connect()

const app = express()
const port = envConfig.port

const corsOptions: CorsOptions = {
  origin: '*',
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  preflightContinue: false,
  optionsSuccessStatus: 204
}

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 3,
  standardHeaders: 'draft-7',
  legacyHeaders: false
})

// create uploads folder if doesnt exist
initFolder()

app.use(express.json())
app.use(helmet())
app.use(cors(corsOptions))
app.use(limiter)

app.use('/users', userRouter)
app.use('/medias', mediaRoutes)
app.use('/tweets', tweetRoutes)
app.use('/static', staticRoutes)
app.use('/bookmark', bookmarkRoutes)
app.use('/like', likeRoutes)
app.use('/static/videos', express.static(UPLOAD_VIDEO_DIR))
app.use('/search', searchRoutes)
app.use(defaultErrorHandler)

app.listen(port, () => {
  console.log(`App is running on http://localhost:${port}`)
})

// test
// À, trên window thì nên run bằng bash terminal chứ không nên run bằng powershell terminal
// Thành công rồi đó, để anh tranh thủ test run thử trên terminal cmd thử
// Chỉ run được trên Bash terminal thôi, vậy cứ dùng bash terminal nhé em!

// const test = async () => {
//   const result = await checkVideoHasAudio(
//     'C:/Users/luongtruong20201/Desktop/BE/project-tw/tw/uploads/images/temp/2cb39ff0-06c9-4699-b9a8-6c03aab57c37.mp4'
//   )
//   console.log(result)
// }

// test()
